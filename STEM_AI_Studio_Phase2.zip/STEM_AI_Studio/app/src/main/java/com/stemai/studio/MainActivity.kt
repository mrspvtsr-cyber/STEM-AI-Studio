package com.stemai.studio

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import android.os.Handler
import android.os.Looper
import com.stemai.studio.audio.AudioDecoder
import com.stemai.studio.audio.Demucs6Separator

private val BrandOrange = Color(0xFFE87524)
private val Ink = Color(0xFF202124)
private val Muted = Color(0xFF73777D)
private val Soft = Color(0xFFFFF4EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                StemHome(
                    onResolveName = { uri -> getDisplayName(uri) }
                )
            }
        }
    }

    private fun getDisplayName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && it.moveToFirst()) return it.getString(index)
        }
        return uri.lastPathSegment ?: "Audio terpilih"
    }
}

@Composable
private fun StemHome(onResolveName: (Uri) -> String) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("Belum ada audio") }
    var isPlaying by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var status by remember { mutableStateOf("Pilih file audio untuk memulai.") }
    var isSeparating by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var resultFiles by remember { mutableStateOf<List<File>>(emptyList()) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            player?.release()
            player = null
            selectedUri = uri
            resultFiles = emptyList()
            selectedName = onResolveName(uri)
            isPlaying = false
            status = "Audio siap. Model HT-Demucs 6S berjalan lokal saat separation."
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            player?.release()
            player = null
        }
    }

    LaunchedEffect(player) {
        player?.setOnCompletionListener {
            isPlaying = false
            it.seekTo(0)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFFAFAF8)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 22.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "STEM AI",
                        color = Ink,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        "STUDIO",
                        color = BrandOrange,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(Soft, RoundedCornerShape(15.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = BrandOrange,
                        modifier = Modifier.size(27.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(
                    "Pisahkan musik.",
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Bold,
                    color = Ink
                )
                Text(
                    "Studio pemisah stem audio berbasis AI, dirancang untuk pemrosesan lokal di Android.",
                    color = Muted,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.UploadFile,
                            contentDescription = null,
                            tint = BrandOrange
                        )
                        Text(
                            "  IMPORT AUDIO",
                            color = Ink,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Soft, RoundedCornerShape(16.dp))
                            .padding(18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.AudioFile,
                                contentDescription = null,
                                tint = BrandOrange,
                                modifier = Modifier.size(38.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                selectedName,
                                color = Ink,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "Pilih MP3, WAV, FLAC, atau format audio lain",
                                color = Muted,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Button(
                        onClick = { picker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null)
                        Text("  Pilih File Audio")
                    }
                    if (selectedUri != null) {
                        OutlinedButton(
                            onClick = {
                                try {
                                    if (isPlaying) {
                                        player?.pause()
                                        isPlaying = false
                                    } else {
                                        if (player == null) {
                                            player = MediaPlayer().apply {
                                                setDataSource(
                                                    // SAF URI; no broad storage permission required.
                                                    context,
                                                    selectedUri!!
                                                )
                                                prepare()
                                            }
                                        }
                                        player?.start()
                                        isPlaying = true
                                    }
                                    status = if (isPlaying) "Memutar audio." else "Playback dijeda."
                                } catch (e: Exception) {
                                    status = "Tidak dapat memutar file: ${e.localizedMessage ?: "format tidak didukung"}"
                                    isPlaying = false
                                    player?.release()
                                    player = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(13.dp)
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null
                            )
                            Text(if (isPlaying) "  Pause Preview" else "  Preview Audio")
                        }
                    }
                }
            }

            Text("OUTPUT STEM", fontWeight = FontWeight.Bold, color = Ink, fontSize = 13.sp)
            val stems = listOf("Vocals", "Drums", "Bass", "Guitar", "Piano", "Other")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                stems.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { stem ->
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(13.dp)
                            ) {
                                Text(
                                    stem,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                                    color = Ink,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Text(
                status,
                color = Muted,
                fontSize = 12.sp
            )
            if (isSeparating) {
                Text("AI separation: $progress%", color = BrandOrange, fontWeight = FontWeight.Bold)
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = BrandOrange
                )
            }
            if (resultFiles.isNotEmpty()) {
                Text("Hasil tersimpan: ${resultFiles.size} file WAV", color = BrandOrange, fontWeight = FontWeight.Bold)
                resultFiles.forEach { file ->
                    Text("${file.name} • ${file.length() / 1024} KB", color = Muted, fontSize = 11.sp)
                }
            }
            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    if (!isSeparating) {
                        isSeparating = true
                        progress = 0
                        status = "Mendekode audio dan menjalankan HT-Demucs 6S secara offline..."
                        scope.launch {
                            try {
                                val pcm = withContext(Dispatchers.IO) { AudioDecoder.decode(context, uri) }
                                val output = withContext(Dispatchers.IO) {
                                    Demucs6Separator(context).separate(
                                        pcm.samples,
                                        File(context.getExternalFilesDir(null) ?: context.filesDir, "STEM_AI_Studio/stems")
                                    ) { value -> Handler(Looper.getMainLooper()).post { progress = value } }
                                }
                                resultFiles = output
                                status = "Selesai. Enam stem WAV tersimpan di folder aplikasi."
                            } catch (e: Exception) {
                                status = "Separation gagal: ${e.message ?: e.javaClass.simpleName}"
                            } finally {
                                isSeparating = false
                            }
                        }
                    }
                },
                enabled = selectedUri != null && !isSeparating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandOrange,
                    disabledContainerColor = Color(0xFFE6D8CE)
                ),
                shape = RoundedCornerShape(15.dp)
            ) {
                Icon(Icons.Default.GraphicEq, contentDescription = null)
                Text(if (isSeparating) "  PROCESSING..." else "  START AI SEPARATION", fontWeight = FontWeight.Bold)
            }
            Text(
                "PHASE 2 • OFFLINE HT-DEMUCS 6-STEM ENGINE",
                modifier = Modifier.fillMaxWidth(),
                color = Muted,
                fontSize = 10.sp,
                letterSpacing = 1.2.sp
            )
        }
    }
}

