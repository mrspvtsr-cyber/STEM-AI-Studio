package com.stemai.studio.audio

import android.content.Context
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.io.RandomAccessFile
import java.nio.FloatBuffer
import java.nio.ByteOrder
import kotlin.math.min

/** HT-Demucs 6S ONNX runner. Input: [1,2,343980], output: [1,6,2,343980]. */
class Demucs6Separator(private val context: Context) {
    companion object {
        const val MODEL_ASSET = "htdemucs_6s_fp16weights.onnx"
        const val SEGMENT = 343980
        const val OVERLAP = 44100
        val STEMS = listOf("drums", "bass", "other", "vocals", "guitar", "piano")
    }

    fun separate(interleavedStereo: FloatArray, outputDir: File, onProgress: (Int) -> Unit): List<File> {
        require(interleavedStereo.size >= 2) { "Audio tidak berisi sampel." }
        require(interleavedStereo.size % 2 == 0) { "Data audio stereo tidak valid." }
        outputDir.mkdirs()
        val totalFrames = interleavedStereo.size / 2
        val step = SEGMENT - OVERLAP
        val starts = generateSequence(0) { it + step }.takeWhile { it < totalFrames }.toList()
        val files = STEMS.map { File(outputDir, "$it.wav") }
        val writers = files.map { WavRandomWriter(it, totalFrames) }
        val env = OrtEnvironment.getEnvironment()
        val modelFile = copyModelFromAssets()
        val options = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(2)
            setInterOpNumThreads(1)
            setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL)
            setMemoryPatternOptimization(false)
        }
        try {
            env.createSession(modelFile.absolutePath, options).use { session ->
                starts.forEachIndexed { chunkIndex, start ->
                    val input = FloatArray(2 * SEGMENT)
                    val valid = min(SEGMENT, totalFrames - start)
                    for (i in 0 until valid) {
                        input[i] = interleavedStereo[(start + i) * 2]
                        input[SEGMENT + i] = interleavedStereo[(start + i) * 2 + 1]
                    }
                    val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, 2, SEGMENT.toLong()))
                    try {
                        session.run(mapOf("mix" to tensor)).use { result ->
                            val out = result.get("stems").get() as OnnxTensor
                            val buffer = out.floatBuffer
                            for (stem in 0 until 6) {
                                val base = stem * 2 * SEGMENT
                                val left = FloatArray(valid)
                                val right = FloatArray(valid)
                                for (i in 0 until valid) {
                                    left[i] = buffer.get(base + i)
                                    right[i] = buffer.get(base + SEGMENT + i)
                                }
                                val blend = if (chunkIndex == 0) 0 else min(OVERLAP, valid)
                                writers[stem].writeChunk(start, left, right, blend)
                            }
                        }
                    } finally { tensor.close() }
                    onProgress(((chunkIndex + 1) * 100) / starts.size)
                }
            }
        } finally {
            options.close()
            writers.forEach { it.close() }
        }
        return files
    }

    private fun copyModelFromAssets(): File {
        val target = File(context.filesDir, MODEL_ASSET)
        if (target.exists() && target.length() > 100_000_000L) return target
        context.assets.open(MODEL_ASSET).use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        return target
    }

    private class WavRandomWriter(file: File, private val frames: Int) : AutoCloseable {
        private val raf = RandomAccessFile(file, "rw")
        init { raf.setLength(44L + frames * 4L); writeHeader() }
        private fun writeHeader() {
            raf.seek(0)
            raf.writeBytes("RIFF"); writeIntLE(36 + frames * 4); raf.writeBytes("WAVE")
            raf.writeBytes("fmt "); writeIntLE(16); writeShortLE(1); writeShortLE(2)
            writeIntLE(44100); writeIntLE(44100 * 4); writeShortLE(4); writeShortLE(16)
            raf.writeBytes("data"); writeIntLE(frames * 4)
        }
        fun writeChunk(start: Int, left: FloatArray, right: FloatArray, blendFrames: Int) {
            val count = left.size
            if (blendFrames > 0) {
                raf.seek(44L + start * 4L)
                for (i in 0 until blendFrames) {
                    val oldL = readShortLE() / 32768f; val oldR = readShortLE() / 32768f
                    val alpha = (i + 1f) / (blendFrames + 1f)
                    val newL = oldL * (1f - alpha) + left[i] * alpha
                    val newR = oldR * (1f - alpha) + right[i] * alpha
                    raf.seek(44L + (start + i) * 4L); writeSample(newL); writeSample(newR)
                }
            }
            raf.seek(44L + (start + blendFrames) * 4L)
            for (i in blendFrames until count) { writeSample(left[i]); writeSample(right[i]) }
        }
        private fun readShortLE(): Int { val lo = raf.readUnsignedByte(); val hi = raf.readUnsignedByte(); return ((hi shl 8) or lo).toShort().toInt() }
        private fun writeSample(v: Float) { writeShortLE((v.coerceIn(-1f, 1f) * 32767f).toInt()) }
        private fun writeShortLE(v: Int) { raf.write(v and 0xff); raf.write((v shr 8) and 0xff) }
        private fun writeIntLE(v: Int) { writeShortLE(v); writeShortLE(v shr 16) }
        override fun close() = raf.close()
    }
}
