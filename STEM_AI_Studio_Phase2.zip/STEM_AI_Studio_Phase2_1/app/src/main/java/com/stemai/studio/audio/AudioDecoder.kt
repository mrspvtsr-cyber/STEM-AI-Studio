package com.stemai.studio.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.floor

/** Decodes formats supported by Android MediaCodec and resamples to stereo 44.1 kHz. */
object AudioDecoder {
    data class PcmAudio(val samples: FloatArray, val sampleRate: Int = 44100) {
        val frameCount: Int get() = samples.size / 2
    }

    fun decode(context: Context, uri: Uri): PcmAudio {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        var track = -1
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
        }
        require(track >= 0) { "File tidak memiliki track audio." }
        extractor.selectTrack(track)
        val format = extractor.getTrackFormat(track)
        val mime = format.getString(MediaFormat.KEY_MIME) ?: error("Codec audio tidak dikenal.")
        val decoder = MediaCodec.createDecoderByType(mime)
        val pcm = FloatAccumulator()
        var sourceRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var pcmEncoding = android.media.AudioFormat.ENCODING_PCM_16BIT
        decoder.configure(format, null, null, 0)
        decoder.start()
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val input = decoder.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = decoder.outputFormat
                        sourceRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (out.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = out.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outIndex >= 0) {
                        val output = decoder.getOutputBuffer(outIndex)
                        if (output != null && info.size > 0) {
                            output.position(info.offset); output.limit(info.offset + info.size)
                            val b = output.slice().order(ByteOrder.LITTLE_ENDIAN)
                            if (pcmEncoding == android.media.AudioFormat.ENCODING_PCM_FLOAT) {
                                while (b.remaining() >= 4 * channels) {
                                    val frame = FloatArray(channels) { b.float }
                                    pcm.addStereo(frame)
                                }
                            } else {
                                while (b.remaining() >= 2 * channels) {
                                    val frame = FloatArray(channels) { b.short / 32768f }
                                    pcm.addStereo(frame)
                                }
                            }
                        }
                        decoder.releaseOutputBuffer(outIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                }
            }
        } finally {
            try { decoder.stop() } catch (_: Exception) {}
            decoder.release(); extractor.release()
        }
        require(pcm.sizeFrames > 0) { "Audio kosong atau format tidak didukung." }
        return PcmAudio(resample(pcm.toArray(), sourceRate, 44100))
    }

    private fun resample(input: FloatArray, fromRate: Int, toRate: Int): FloatArray {
        if (fromRate == toRate) return input
        val inFrames = input.size / 2
        val outFrames = (inFrames.toLong() * toRate / fromRate).toInt().coerceAtLeast(1)
        val out = FloatArray(outFrames * 2)
        for (i in 0 until outFrames) {
            val pos = i.toDouble() * fromRate / toRate
            val a = floor(pos).toInt().coerceIn(0, inFrames - 1)
            val b = (a + 1).coerceAtMost(inFrames - 1)
            val t = (pos - a).toFloat()
            for (ch in 0..1) out[i * 2 + ch] = input[a * 2 + ch] * (1f - t) + input[b * 2 + ch] * t
        }
        return out
    }

    private class FloatAccumulator {
        private var data = FloatArray(32768)
        private var size = 0
        val sizeFrames get() = size / 2
        fun addStereo(frame: FloatArray) {
            if (size + 2 > data.size) data = data.copyOf(data.size * 2)
            val left = frame.firstOrNull() ?: 0f
            val right = if (frame.size > 1) frame[1] else left
            data[size++] = left.coerceIn(-1f, 1f); data[size++] = right.coerceIn(-1f, 1f)
        }
        fun toArray() = data.copyOf(size)
    }
}
