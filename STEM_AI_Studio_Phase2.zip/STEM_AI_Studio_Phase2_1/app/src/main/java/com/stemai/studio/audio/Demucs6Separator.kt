package com.stemai.studio.audio

import android.content.Context
import android.app.ActivityManager
import android.util.Log
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File
import java.io.RandomAccessFile
import java.nio.FloatBuffer
import kotlin.math.min

/** HT-Demucs 6S ONNX runner. Input: [1,2,343980], output: [1,6,2,343980]. */
class Demucs6Separator(private val context: Context) {
    companion object {
        const val MODEL_ASSET = "htdemucs_6s_fp16weights.onnx"
        const val SEGMENT = 343980
        const val OVERLAP = 44100
        private const val MIN_AVAILABLE_RAM_BYTES = 1280L * 1024L * 1024L
        private const val TAG = "STEM-Demucs"
        val STEMS = listOf("drums", "bass", "other", "vocals", "guitar", "piano")
    }

    fun separate(interleavedStereo: FloatArray, outputDir: File, onProgress: (Int) -> Unit): List<File> {
        require(interleavedStereo.size >= 2) { "Audio tidak berisi sampel." }
        require(interleavedStereo.size % 2 == 0) { "Data audio stereo tidak valid." }
        outputDir.mkdirs()
        checkModelAsset()
        checkAvailableMemory()
        val totalFrames = interleavedStereo.size / 2
        val step = SEGMENT - OVERLAP
        val starts = generateSequence(0) { it + step }.takeWhile { it < totalFrames }.toList()
        val files = STEMS.map { File(outputDir, "$it.wav") }
        val writers = files.map { WavRandomWriter(it, totalFrames) }
        val env = OrtEnvironment.getEnvironment()
        val modelFile = copyModelFromAssets()
        val options = OrtSession.SessionOptions().apply {
            // One worker reduces peak native-memory pressure on older phones.
            setIntraOpNumThreads(1)
            setInterOpNumThreads(1)
            setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL)
            setMemoryPatternOptimization(false)
        }
        try {
            Log.i(TAG, "Creating ONNX session; modelBytes=${modelFile.length()}, availableMem=${availableMemoryBytes()}")
            env.createSession(modelFile.absolutePath, options).use { session ->
                require(session.inputNames.contains("mix")) {
                    "Input model tidak sesuai: nama input 'mix' tidak ditemukan. Input: ${session.inputNames}"
                }
                require(session.outputNames.contains("stems")) {
                    "Output model tidak sesuai: nama output 'stems' tidak ditemukan. Output: ${session.outputNames}"
                }
                Log.i(TAG, "ONNX session ready; inputs=${session.inputNames}; outputs=${session.outputNames}")
                starts.forEachIndexed { chunkIndex, start ->
                    val input = FloatArray(2 * SEGMENT)
                    val valid = min(SEGMENT, totalFrames - start)
                    for (i in 0 until valid) {
                        input[i] = interleavedStereo[(start + i) * 2]
                        input[SEGMENT + i] = interleavedStereo[(start + i) * 2 + 1]
                    }
                    val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, 2, SEGMENT.toLong()))
                    try {
                        session.run(mapOf("mix" to tensor)).use { result ->
                            val out = result.get("stems").get() as OnnxTensor
                            val buffer = out.floatBuffer
                            for (stem in 0 until 6) {
                                val base = stem * 2 * SEGMENT
                                val left = FloatArray(valid)
                                val right = FloatArray(valid)
                                for (i in 0 until valid) {
                                    left[i] = buffer.get(base + i)
                                    right[i] = buffer.get(base + SEGMENT + i)
                                }
                                val blend = if (chunkIndex == 0) 0 else min(OVERLAP, valid)
                                writers[stem].writeChunk(start, left, right, blend)
                            }
                        }
                    } finally { tensor.close() }
                    onProgress(((chunkIndex + 1) * 100) / starts.size)
                }
            }
        } catch (oom: OutOfMemoryError) {
            Log.e(TAG, "Native/Java memory exhausted during Demucs inference", oom)
            throw IllegalStateException(
                "Memori HP tidak cukup untuk memuat HT-Demucs 6-Stem. Tutup aplikasi lain lalu coba lagi. Jika tetap gagal, model FP16 ini terlalu berat untuk konfigurasi perangkat.",
                oom
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Demucs inference failed", t)
            throw t
        } finally {
            options.close()
            writers.forEach { try { it.close() } catch (_: Exception) {} }
        }
        return files
    }

    private fun checkModelAsset() {
        try {
            context.assets.open(MODEL_ASSET).use { input ->
                val first = input.read()
                require(first >= 0) { "File model ONNX kosong." }
            }
        } catch (e: Exception) {
            throw IllegalStateException("Model AI tidak ditemukan di APK: $MODEL_ASSET. Build ulang melalui GitHub Actions.", e)
        }
    }

    private fun availableMemoryBytes(): Long {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        return info.availMem
    }

    private fun checkAvailableMemory() {
        val available = availableMemoryBytes()
        val availableMb = available / (1024L * 1024L)
        val requiredMb = MIN_AVAILABLE_RAM_BYTES / (1024L * 1024L)
        Log.i(TAG, "Memory preflight: available=${availableMb}MB; threshold=${requiredMb}MB")
        if (available < MIN_AVAILABLE_RAM_BYTES) {
            throw IllegalStateException(
                "RAM bebas saat ini ${availableMb} MB. HT-Demucs 6-Stem memerlukan ruang memori besar (sekitar 1.1 GB atau lebih). Tutup aplikasi lain, restart HP, lalu coba lagi."
            )
        }
    }

    private fun copyModelFromAssets(): File {
        val target = File(context.filesDir, MODEL_ASSET)
        if (target.exists() && target.length() > 100_000_000L) return target
        context.assets.open(MODEL_ASSET).use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        return target
    }

    private class WavRandomWriter(file: File, private val frames: Int) : AutoCloseable {
        private val raf = RandomAccessFile(file, "rw")
        init { raf.setLength(44L + frames * 4L); writeHeader() }
        private fun writeHeader() {
            raf.seek(0)
            raf.writeBytes("RIFF"); writeIntLE(36 + frames * 4); raf.writeBytes("WAVE")
            raf.writeBytes("fmt "); writeIntLE(16); writeShortLE(1); writeShortLE(2)
            writeIntLE(44100); writeIntLE(44100 * 4); writeShortLE(4); writeShortLE(16)
            raf.writeBytes("data"); writeIntLE(frames * 4)
        }
        fun writeChunk(start: Int, left: FloatArray, right: FloatArray, blendFrames: Int) {
            val count = left.size
            if (blendFrames > 0) {
                raf.seek(44L + start * 4L)
                for (i in 0 until blendFrames) {
                    val oldL = readShortLE() / 32768f; val oldR = readShortLE() / 32768f
                    val alpha = (i + 1f) / (blendFrames + 1f)
                    val newL = oldL * (1f - alpha) + left[i] * alpha
                    val newR = oldR * (1f - alpha) + right[i] * alpha
                    raf.seek(44L + (start + i) * 4L); writeSample(newL); writeSample(newR)
                }
            }
            raf.seek(44L + (start + blendFrames) * 4L)
            for (i in blendFrames until count) { writeSample(left[i]); writeSample(right[i]) }
        }
        private fun readShortLE(): Int { val lo = raf.readUnsignedByte(); val hi = raf.readUnsignedByte(); return ((hi shl 8) or lo).toShort().toInt() }
        private fun writeSample(v: Float) { writeShortLE((v.coerceIn(-1f, 1f) * 32767f).toInt()) }
        private fun writeShortLE(v: Int) { raf.write(v and 0xff); raf.write((v shr 8) and 0xff) }
        private fun writeIntLE(v: Int) { writeShortLE(v); writeShortLE(v shr 16) }
        override fun close() = raf.close()
    }
}
